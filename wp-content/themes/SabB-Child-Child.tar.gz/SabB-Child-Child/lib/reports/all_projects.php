<?php
function billyB_all_projects()
{
	if(!is_user_logged_in()) { wp_redirect(get_bloginfo('siteurl')."/wp-login.php"); exit; }

	global $current_user,$wpdb,$wp_query;
	get_currentuserinfo();
	$uid = $current_user->ID;
	$rights_results = $wpdb->get_results($wpdb->prepare("select team from ".$wpdb->prefix."useradd where user_id=%d",$uid));
	$team = $rights_results[0]->team;

	$allowed_teams = array('Finance');
 
	if(!in_array($team,$allowed_teams) and $uid !=103 and $uid!=107 and $uid != 116)
	{ wp_redirect(get_bloginfo('siteurl')."/dashboard"); exit; }
	
	if(isset($_POST['save-info']))
	{
		$records = $_POST['record'];
		
		foreach($records as $record)
		{
			$abb_name = $record['abb_name'];
			$orig_name = $record['orig'];
			$project_id = $record['project'];
			$project_manager = $record['project_manager'];
			$orig_pm = $record['orig_pm'];
			
			if($abb_name != $orig_name or ($project_manager != $orig_pm and !empty($project_manager)))
			{
				$wpdb->query($wpdb->prepare("update ".$wpdb->prefix."projects set abbreviated_name=%s,project_manager=%d where ID=%s",
					$abb_name,$project_manager,$project_id));
			}
		}
	}
	
		?>   
		<form method="post" enctype="multipart/form-data">
		<div id="content_full">
			<div class="my_box3">
			<div class="padd10">
			<ul class="other-dets_m">
			<?php
			$filter = "all";
			if(isset($_POST['submit_document'])){$filter = $_POST['select_document'];}
			$active_projects_query = "select ID,project_name,gp_id,client_name,abbreviated_name,sphere,current_document,project_manager 
				from ".$wpdb->prefix."projects 
				inner join ".$wpdb->prefix."clients on ".$wpdb->prefix."projects.client_id=".$wpdb->prefix."clients.client_id 
				where status<4 and project_parent=0 order by sphere,-abbreviated_name desc,gp_id";
			$filtered_projects_query = "select ID,project_name,gp_id,client_name,abbreviated_name,sphere,current_document,project_manager 
				from ".$wpdb->prefix."projects 
				inner join ".$wpdb->prefix."clients on ".$wpdb->prefix."projects.client_id=".$wpdb->prefix."clients.client_id 
				where status<4 and project_parent=0 and current_document='$filter'
				order by sphere,-abbreviated_name desc,gp_id";
			$active_projects_results = $wpdb->get_results($active_projects_query);
			
			$active_users = $wpdb->get_results($wpdb->prepare("select user_id,display_name from ".$wpdb->prefix."users
				inner join ".$wpdb->prefix."useradd on ".$wpdb->prefix."users.ID=".$wpdb->prefix."useradd.user_id
				where status=1 order by display_name"));
			
			if($uid == 11 or $uid == 103 or $uid==107 or $uid==94){echo '<li><input type="submit" class="my-buttons" name="save-info" value="SAVE" /></li><li>&nbsp;</li>';}
			if($uid == 11){echo '<li>&nbsp;</li>';}
			if($uid == 11 or $uid == 94)
			{
				$document_array = array();
				foreach($active_projects_results as $apr)
				{
					if(!in_array($apr->current_document,$document_array) and !empty($apr->current_document))
					{
						array_push($document_array,$apr->current_document);
					}
				}
				echo '<li><select name="select_document" class="do_input_new">
					<option value="all" '.($filter=="all" ? 'selected="selected"' : '' ).'>All Contracts</option>
					<option value="" '.($filter=="" ? 'selected="selected"' : '' ).'>No Document Identified</option>';
				foreach($document_array as $da)
				{
					echo '<option '.($filter==$da ? 'selected="selected"' : '' ).'>'.$da.'</option>';
				}
				echo '</select>
					<input type="submit" name="submit_document" value="Filter Contracts" class="my-buttons" />
					</li>';
			}
			
			echo '<li><table width=100%">
				<tr>
				<th><b><u>Project</u></b></th>
				<th><b><u>Sphere</u></b></th>
				'.(($uid==11 or $uid==104) ? '<th><b><u>Project Manager</u></b></th>' : '' ).'
				<th><b><u>Abbreviated Name</u></b></th>
				'.(($uid == 11 or $uid == 94) ? '<th><b><u>Checklist</u></b></th>' : '' ).'
				<th><b><u>Project Card</u></b></th>
				</tr>';
			
			if(isset($_POST['submit_document']) and $filter !="all"){$active_projects_results = $wpdb->get_results($filtered_projects_query);}
			else{$active_projects_results = $wpdb->get_results($active_projects_query);}
			
			foreach($active_projects_results as $project)
			{
				echo '<tr><th>'.$project->client_name.' - '.$project->project_name.' - '.$project->gp_id.'</th>
					<th>'.$project->sphere.'</th>';
				if($uid==11 or $uid==104)
				{	
					echo '<th><select name="record['.$project->ID.'][project_manager]" class="do_input_new"><option value="">Select PM</option>';
					foreach($active_users as $user)
					{
						echo '<option value="'.$user->user_id.'" '.($project->project_manager==$user->user_id ? 'selected="selected"' : '' ).'>'.$user->display_name.'</option>';
					}
					echo '</select></th>';
				}
					 
				echo (($uid == 11 or $uid == 103 or $uid==94 or $uid==107) ? '<th><input type="text" name="record['.$project->ID.'][abb_name]" class="do_input_new" value="'.$project->abbreviated_name.'" />
					<input type="hidden" name="record['.$project->ID.'][project]" value="'.$project->ID.'" />
					<input type="hidden" name="record['.$project->ID.'][orig]" value="'.$project->abbreviated_name.'" />
					<input type="hidden" name="record['.$project->ID.'][orig_pm]" value="'.$project->project_manager.'" /></th>' : '').'
					'.(($uid == 11 or $uid==94) ? '<th><a href="/?p_action=edit_checklist&ID='.$project->ID.'">View Checklist</a></th>' : '').'
					<th><a href="/?p_action=project_card&ID='.$project->ID.'">View Project Card</a></th></tr>';
			}
			echo '</table></li>';
			if($uid == 11 or $uid == 103 or $uid==107 or $uid==94){echo '<li><input type="submit" class="my-buttons" name="save-info" value="SAVE" /></li>';}
			?>
			</ul>
			</div>
			</div>						
		</div>
		</form>
<?php }
add_shortcode('all_projects','billyB_all_projects')
?>