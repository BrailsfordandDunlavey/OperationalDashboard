<?php

	global $wpdb, $current_user;
	get_currentuserinfo();
	$cid = $current_user->ID;
	
	$employee_id = $_GET['ID'];
	
	$user_results = $wpdb->get_results($wpdb->prepare("select * from ".$wpdb->prefix."users where ID=%d",$employee_id));
	$email = $user_results[0]->user_email;
	$employee_name = $user_results[0]->display_name;
	
	function sitemile_filter_ttl($title){return __("User Profile",'ProjectTheme');}
	add_filter( 'wp_title', 'sitemile_filter_ttl', 10, 3 );	
	$useradd_results = $wpdb->get_results($wpdb->prepare("select * from ".$wpdb->prefix."useradd where user_id=%d",$employee_id));
	$position_id = $useradd_results[0]->position;
	$sphere = $useradd_results[0]->sphere;
	$office_phone = $useradd_results[0]->office_phone;
	$cell_phone = $useradd_results[0]->cell_phone;
	
	$position_results = $wpdb->get_results($wpdb->prepare("select position_title from ".$wpdb->prefix."position where ID=%d",$position_id));
	$position = $position_results[0]->position_title;
	
	$year = date('Y',time());
	$assumptions_results = $wpdb->get_results($wpdb->prepare("select * from ".$wpdb->prefix."position_assumptions where position_id=%d and year=%d",$position_id,$year));
	$planning_rate = $assumptions_results[0]->planning_rate;
	$implementation_rate = $assumptions_results[0]->implementation_rate;
	
get_header();
?>
    <div class="page_heading_me">
		<div class="page_heading_me_inner"> 
            <div class="mm_inn"><?php printf(__("User Profile - %s", 'ProjectTheme'), $employee_name); ?>   </div>                            
        </div>            
    </div>
<div id="main_wrapper">
	<div id="main" class="wrapper">
		<div id="content">
    		<div class="my_box3">
            <div class="padd10">
            	<div class="box_content">	
                <div class="user-profile-description">                     
                	<p>
						<ul class="other-dets_m">
							<?php
							echo '<li><h3>Email:</h3><p>'.$email.'</p></li>';
							echo '<li><h3>Office Phone:</h3><p>'.($office_phone != 0 ? '('.substr($office_phone, 0, 3).') '.substr($office_phone, 3, 3).'-'.substr($office_phone,6) 
								: 'Not Listed').'</p></li>';
							echo '<li><h3>Cell Phone:</h3><p>'.($cell_phone != 0 ? '('.substr($cell_phone, 0, 3).') '.substr($cell_phone, 3, 3).'-'.substr($cell_phone,6) 
								: 'Not Listed').'</p></li>';
							echo '<li>&nbsp;</li>';
							echo '<li><h3>Position:</h3><p>'.$position.'</p></li>';
							echo '<li><h3>Planning Rate:</h3><p>$'.number_format($planning_rate,2).'</p></li>';
							echo '<li><h3>Implementation Rate:</h3><p>$'.number_format($implementation_rate,2).'</p></li>';
							?>
			             </ul>
					</p>
                </div>   
                </div>
            </div>
            </div>
		</div>
	</div>
</div> 
<?php
	get_footer();
?>
