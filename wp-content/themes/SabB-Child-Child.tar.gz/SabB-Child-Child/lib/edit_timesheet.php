<?php
get_header();
if(!is_user_logged_in()) { wp_redirect(get_bloginfo('siteurl')."/wp-login.php"); exit; }

	global $current_user,$wpdb,$wp_query;
	get_currentuserinfo();
	$uid = $current_user->ID;
	if(isset($_POST['set_id'])){$uid = $_POST['change_id'];}
 	$timesheet = $_GET['ID'];
	$now = time();
	$days_back = 60;
	$deadline = $now - (86400 * $days_back);
	if($deadline > $timesheet)
	{
		?>
		<div id="main_wrapper">
			<div id="main" class="wrapper">	
		<div id="content">
		<div class="my_box3">
			<div class="padd10">
			Sorry, but this time period is now closed.  If you feel you still need to make edits, please contact Bill Bannister.  Thank you.
			</div>
		</div>
		</div>
			</div>
		</div>
		<?php
		 get_footer();exit;
	}
	?>
	<div id="main_wrapper">
		<div id="main" class="wrapper">
	<?php
	if(isset($_POST['save-info']))
	{
		?>
		<div id="content">
		<div class="my_box3">
			<div class="padd10">
			<?php
					
			$records = ($_POST['record']);
			$timeoff_array = array('Vacation','Sick','Float','Bereav','Jury','Mat/Pat');
					
			foreach($records as $record)
			{
				$original_project = $record['original'];
				$original_hours = $record['orig_hours'];
				$timesheet_id = $record['id'];
				$submitted = time();
				$project = $record['project'];
				if(empty($project)){$project = $original_project;}
				$hours = $record['hours'];
				$notes = $record['notes'];
				
				if(in_array($original_project,$timeoff_array))
				{
					$time_off_results = $wpdb->get_results($wpdb->prepare("select * from ".$wpdb->prefix."request_timeoff where employee_id=%d and request_type=%s and request_date=%d 
						and request_hours=%f",$uid,$original_project,$timesheet,$original_hours));
				}
				if($hours == 0)
				{
					if(in_array($original_project,$timeoff_array))//need to check the status of the request before deleting
					{
						if($time_off_results[0]->request_status<=2)
						{
							$wpdb->query($wpdb->prepare("delete from ".$wpdb->prefix."request_timeoff where request_id=%d",$time_off_results[0]->request_id));
						}
						else
						{
							$negative_hours = $original_hours*-1;
							$wpdb->query($wpdb->prepare("insert into ".$wpdb->prefix."request_timeoff (request_report_id,employee_id,request_date,request_type,request_code,request_hours,
								request_status,date_requested) values(%d,%d,%d,%s,%s,%f,1,%d)",$time_off_results[0]->request_report_id,$time_off_results[0]->employee_id,
								$time_off_results[0]->request_date,$time_off_results[0]->request_type,$time_off_results[0]->request_code,$negative_hours,$submitted));
						}
					}
					$wpdb->query($wpdb->prepare("delete from ".$wpdb->prefix."timesheets where timesheet_id=%d",$timesheet_id));
				}
				else//if hours != 0
				{
					if(in_array($original_project,$timeoff_array) and ($original_project!=$project or $original_hours!=$hours))//if the orignal project was a time-off request and the project or hours changed
					{
						if($time_off_results[0]->request_status<=2)//simply update the request if it's not been uploaded to ADP yet
						{
							$wpdb->query($wpdb->prepare("update ".$wpdb->prefix."request_timeoff set request_type=%s,request_hours=%f
								where request_id=%d",$project,$hours,$time_off_results[0]->request_id)); 
						}
						else
						{
							//enter a reversal of the original entry
							$wpdb->query($wpdb->prepare("insert into ".$wpdb->prefix."request_timeoff (request_report_id,employee_id,request_date,request_type,request_code,request_hours,
								request_status,date_requested) values(%d,%d,%d,%s,%s,%f,1,%d)",$time_off_results[0]->request_report_id,$time_off_results[0]->employee_id,
								$time_off_results[0]->request_date,$original_project,$time_off_results[0]->request_code,$original_hours*-1,$submitted));
							
							//enter a new entry if the new entry is another request for timeoff
							if(in_array($project,$timeoff_array))
							{
								if($project == 'Vacation'){$code='V';}elseif($project=='Sick'){$code='S';}elseif($project=='Holiday'){$code='H';}
									elseif($project=='Bereav'){$code='B';}elseif($project=='Float'){$code='F';}elseif($project=='Jury'){$code='J';}else{$code='M';}
									
								$wpdb->query($wpdb->prepare("insert into ".$wpdb->prefix."request_timeoff ((request_report_id,employee_id,request_date,request_type,request_code,request_hours,
									request_status,date_requested) values(%d,%d,%d,%s,%s,%f,1,%d)",$time_off_results[0]->request_report_id,$time_off_results[0]->employee_id,
									$time_off_results[0]->request_date,$project,$code,$hours,$submitted));
							}
								
						}
					}
					if(in_array($project,$timeoff_array))
					{
						if($project == 'Vacation'){$code='V';}elseif($project=='Sick'){$code='S';}elseif($project=='Holiday'){$code='H';}
							elseif($project=='Bereav'){$code='B';}elseif($project=='Float'){$code='F';}elseif($project=='Jury'){$code='J';}else{$code='M';}
							
						$wpdb->query($wpdb->prepare("insert into ".$wpdb->prefix."request_timeoff ((request_report_id,employee_id,request_date,request_type,request_code,request_hours,
							request_status,date_requested) values(%d,%d,%d,%s,%s,%f,1,%d)",$time_off_results[0]->request_report_id,$time_off_results[0]->employee_id,
							$time_off_results[0]->request_date,$project,$code,$negative_hours,$submitted));
					}
					$wpdb->query($wpdb->prepare("update ".$wpdb->prefix."timesheets set submitted_date=%d,project_id=%s,timesheet_hours=%f,timesheet_notes=%s,approved_by=0,
						approved_date=0,timesheet_status=0 where timesheet_id=%d",$submitted,$project,$hours,$notes,$timesheet_id));
				}
			}
			echo "The timesheet has been saved.<br/><br/>";
			?>
			<a href="<?php bloginfo('siteurl');?>/new-timesheet/"><?php echo "Enter a new Timesheet";?></a><br/><br/>
			<a href="<?php bloginfo('siteurl'); ?>/dashboard/"><?php echo "Return to your Dashboard";?></a>
			</div>
		</div>
		</div>
		<?php 
	} ?> 
	<form method="post"  enctype="multipart/form-data">
		<div id="content">
			<div class="my_box3">
				<div class="padd10">
					<ul class="other-dets_m">
					<?php
					if($current_user->ID==11)
					{
						echo '<li><select class="do_input_new" name="change_id">';
						$users_results = $wpdb->get_results("select ".$wpdb->prefix."users.ID,display_name from ".$wpdb->prefix."users
							inner join ".$wpdb->prefix."useradd on ".$wpdb->prefix."users.ID=".$wpdb->prefix."useradd.user_id
							where ".$wpdb->prefix."useradd.status=1 order by display_name");
						foreach($users_results as $user)
						{
							echo '<option value="'.$user->ID.'" '.($uid==$user->ID ? "selected='selected'" : "").'>'.$user->display_name.'</option>';
						}
						echo '</select></li>';
						echo '<li><input type="submit" name="set_id" class="my-buttons" value="Change ID" /></li>';
					}
					?>
					<li><p><input type="submit" name="save-info" class="my-buttons" value="<?php echo "Save"; ?>" /></p></li>
					<li>&nbsp;</li>
					<li>
					<style>input[type=number]{width:70px;}</style>
					<?php 
					$timeresults = $wpdb->get_results($wpdb->prepare("select * from ".$wpdb->prefix."timesheets where timesheet_date=%d and user_id=%d",$timesheet,$uid));
					if(!empty($timeresults))
					{
						$t = -1;
						
						$resultactive = $wpdb->get_results($wpdb->prepare("select distinct ".$wpdb->prefix."projects.ID,client_id,abbreviated_name,project_name,gp_id from ".$wpdb->prefix."projects 
							inner join ".$wpdb->prefix."project_user on ".$wpdb->prefix."projects.ID=".$wpdb->prefix."project_user.project_id 
							where ".$wpdb->prefix."project_user.user_id=%d and ".$wpdb->prefix."projects.status=2 and project_parent=0",$uid));
						
						$admin_results = $wpdb->get_results("select * from ".$wpdb->prefix."other_project_codes where timesheet_available=1 order by other_project_code_name");
						
						foreach ($timeresults as $time)
						{
							$t = $t++;
							$date = date('m-d',$time->timesheet_date);
							echo '<div id="'.$t.'" style="display:inline-block;">Date: <select class="do_input_new"><option>'.$date.'</option></select></div>';
							echo '<div id="'.$t.'" style="display:inline-block;"> Project: <select class="do_input_new" name="record['.$time->timesheet_id.'][project]"
								'.($time->timesheet_status > 0 ? "disabled='disabled'" : "" ).' >';
							echo '<option value="">Select Project</option>';
							foreach ($resultactive as $active)
							{
								$p = '<option value="'.$active->ID.'" ';
								if($time->project_id == $active->ID){$p .= 'selected="selected" ';}
								$p .= '>'.(empty($active->abbreviated_name) ? $active->gp_id : $active->abbreviated_name).'</option>';
								echo $p;
							}
							
							foreach($admin_results as $admin)
							{
								echo '<option value="'.$admin->other_project_code_value.'" '.
									($time->project_id == $admin->other_project_code_value ? "selected='selected'" : "").'
									>'.$admin->other_project_code_name.'</option>';
							}
							
							$othercodes = array('Vacation','Sick','Holiday','Bereav','Float','Jury','Mat/Pat');
							foreach($othercodes as $code)
							{
								echo '<option ';
								if($time->project_id == $code){echo 'selected="selected"';}
								echo ' >'.$code.'</option>';
							}
							echo '</select></div>';
							echo '<input type="hidden" name="record['.$time->timesheet_id.'][id]" value="'.$time->timesheet_id.'" />';
							echo '<input type="hidden" name="record['.$time->timesheet_id.'][original]" value="'.$time->project_id.'" />';
							echo '<input type="hidden" name="record['.$time->timesheet_id.'][orig_hours]" value="'.$time->timesheet_hours.'" />';
							echo '<div id="'.$t.'" style="display:inline-block;"> Hours: <input type="number" step=".25" min="0" max="24" class="do_input_new" value ="'.floatval($time->timesheet_hours).'"
								name="record['.$time->timesheet_id.'][hours]" '.($time->timesheet_status > 0 ? "readonly" : "" ).' /></div>';
							echo '<div id="'.$t.'" style="display:inline-block;"> Notes: <textarea rows="1" cols="60" class="full_wdth_me do_input_new description_edit"
								name="record['.$time->timesheet_id.'][notes]">'.$time->timesheet_notes.'</textarea></div></li><br/><hr><br/>';
						}
					}
					else{echo '<li>There is no data for this timesheet.</li>';}
					?>
					</li>
					<li>&nbsp;</li>
					<li><p><input type="submit" name="save-info" class="my-buttons" value="<?php echo "Save"; ?>" /></li>
					</ul>
				</div>
			</div>
		</div>
	</form>
	<div id="right-sidebar" class="page-sidebar"><div class="padd10"><h3><?php echo "Tips";?></h3>
		<ul class="xoxo">
			<li class="widget-container widget_text" id="ad-other-details">
				<ul class="other-dets other-dets2">
				<li><?php echo 'To delete a line item, enter 0 (zero) hours and click "SAVE"';?></li>
				<li>You cannot edit a timeoff request if it has been uploaded to ADP.  Please enter a <a href="<?php echo get_bloginfo('siteurl')."/request-time-off/";?>" >
					new request</a> for timeoff if you need to edit an existing entry.</li>
				</ul>
			</li>
		</ul>
	</div></div>
		</div>
	</div>
<?php get_footer(); ?>